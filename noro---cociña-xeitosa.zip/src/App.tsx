/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useRef } from 'react';
import headerImage from './header-noro.jpg';
import esenciaImage from './esencia.jpg';
import logoImage from './noro-logo.png';
import prato1 from './prato1.jpg';
import prato2 from './prato2.jpg';
import prato3 from './prato3.jpg';
import ats1 from './ats1.jpg';
import ats2 from './ats2.jpg';
import ats3 from './ats3.jpg';
import ats4 from './ats4.jpg';
import ats5 from './ats5.jpg';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = ["Filosofía", "Carta", "Espazo", "Contacto"];

  return (
    <nav 
      className={`fixed top-0 left-0 w-full h-16 z-[1000] transition-all duration-400 flex items-center justify-between px-6 md:px-12 ${
        isScrolled ? 'bg-bg-primary border-b border-border' : 'bg-transparent'
      }`}
    >
      {/* Logo */}
      <div className="flex-1">
        <a href="#" className="block">
          <img 
            src={logoImage} 
            alt="noro" 
            className={`h-8 w-auto transition-all duration-400 ${
              isScrolled ? '' : 'brightness-0 invert'
            }`}
          />
        </a>
      </div>

      {/* Desktop Links */}
      <div className="hidden md:flex flex-1 justify-center gap-8">
        {navLinks.map((link) => (
          <a
            key={link}
            href={`#${link.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")}`}
            className={`font-sans text-[13px] transition-colors duration-200 hover:text-accent ${
              isScrolled ? 'text-text-primary' : 'text-white/80'
            }`}
          >
            {link}
          </a>
        ))}
      </div>

      {/* CTA */}
      <div className="flex-1 flex justify-end">
        <a
          href="https://wa.me/34886642422"
          className={`font-sans text-[11px] tracking-[0.1em] px-5 py-2.5 transition-all duration-400 ${
            isScrolled 
              ? 'bg-accent text-white' 
              : 'bg-transparent border border-white text-white hover:bg-white hover:text-text-primary'
          }`}
        >
          RESERVAR MESA
        </a>
      </div>

      {/* Mobile Menu Toggle */}
      <button 
        className="md:hidden ml-4 flex flex-col gap-1.5"
        onClick={() => setIsMenuOpen(true)}
      >
        <span className={`w-6 h-px ${isScrolled ? 'bg-text-primary' : 'bg-white'}`}></span>
        <span className={`w-6 h-px ${isScrolled ? 'bg-text-primary' : 'bg-white'}`}></span>
      </button>

      {/* Mobile Overlay */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-bg-dark z-[2000] flex flex-col items-center justify-center gap-8 p-12">
          <button 
            className="absolute top-6 right-6 text-white text-2xl"
            onClick={() => setIsMenuOpen(false)}
          >
            ✕
          </button>
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")}`}
              className="font-serif text-4xl text-white/80 hover:text-white"
              onClick={() => setIsMenuOpen(false)}
            >
              {link}
            </a>
          ))}
          <a
            href="https://wa.me/34886642422"
            className="mt-8 bg-accent text-white px-8 py-4 tracking-widest text-xs"
            onClick={() => setIsMenuOpen(false)}
          >
            RESERVAR MESA
          </a>
        </div>
      )}
    </nav>
  );
};

const Hero = () => {
  return (
    <section id="hero" className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-[#3a3530]"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.3) 50%, rgba(0,0,0,0.55) 100%), url("${headerImage}")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 flex flex-col items-center">
        <span className="font-sans text-[11px] tracking-[0.2em] text-accent uppercase block reveal">
          PONTEVEDRA, GALICIA
        </span>
        <img 
          src={logoImage} 
          alt="noro" 
          className="h-24 md:h-40 w-auto mt-6 mb-4 brightness-0 invert reveal stagger-1"
        />
        <p className="font-serif italic text-white/90 text-2xl md:text-[24px] font-light reveal stagger-2">
          Cociña Xeitosa
        </p>
        <a
          href="https://wa.me/34886642422"
          className="inline-block mt-8 bg-accent text-white px-10 py-4 text-[12px] tracking-[0.12em] hover:bg-accent-hover transition-colors reveal stagger-3"
        >
          RESERVAR MESA
        </a>
      </div>

      {/* Scroll Indicator */}
      <a 
        href="#filosofia"
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 hover:opacity-100 transition-opacity opacity-80"
      >
        <span className="font-sans text-[10px] tracking-[0.2em] text-white/60">DESCUBRIR</span>
        <div className="w-px h-10 bg-white/40 animate-pulse"></div>
      </a>
    </section>
  );
};

const Filosofia = () => {
  return (
    <section id="filosofia" className="py-[120px] px-6 md:px-12 max-w-7xl mx-auto scroll-mt-16">
      <div className="flex flex-col md:flex-row gap-12 md:gap-20 items-center">
        {/* Left Column: Image */}
        <div className="w-full md:w-[45%] relative reveal">
          <div 
            className="aspect-[4/5] bg-[#dcd7d0] w-full bg-cover bg-center"
            style={{ backgroundImage: `url("${esenciaImage}")` }}
          ></div>
          {/* Floating Card */}
          <div className="absolute bottom-[-20px] right-[-10px] md:right-[-40px] bg-white p-6 md:p-7 shadow-xl w-[220px] reveal stagger-1">
            <p className="font-serif italic text-[16px] text-text-primary">
              "Cocinamos con xeito para gente riquiña."
            </p>
          </div>
        </div>

        {/* Right Column: Text */}
        <div className="w-full md:w-[55%] md:pl-20">
          <span className="font-sans text-[11px] tracking-[0.15em] text-accent uppercase block mb-6 reveal">
            NUESTRA ESENCIA
          </span>
          <h2 className="text-[48px] md:text-[56px] text-text-primary leading-tight reveal stagger-1">
            Raíces na terra
          </h2>
          <h2 className="text-[48px] md:text-[56px] italic text-text-primary/50 font-light leading-tight reveal stagger-2">
            & no mar.
          </h2>
          
          <div className="mt-8 space-y-4 reveal stagger-3">
            <p className="text-text-secondary">
              Somos un restaurante gallego contemporáneo en el centro de Pontevedra, con una carta corta, honesta y elaborada con mimo. Apostamos por la tradición con una mirada actual, y por una cocina que combina sabor, cuidado y creatividad.
            </p>
            <p className="text-text-secondary">
              Ofrecemos un servicio cercano y atento, pensado para que cada visita se sienta especial. Nuestra bodega incluye una selección de vinos bien escogida para acompañar cada plato. También contamos con opciones sin gluten.
            </p>
            <p className="text-text-secondary">
              En Noro Cociña Xeitosa cocinamos con xeito para gente riquiña.
            </p>
          </div>

          {/* Pillars */}
          <div className="mt-10 grid grid-cols-3 gap-4 reveal stagger-4">
            {[
              { title: "Mar", subtitle: "PRODUCTO FRESCO" },
              { title: "Terra", subtitle: "TRADICIÓN" },
              { title: "Xeito", subtitle: "CON MIMO" }
            ].map((pillar) => (
              <div key={pillar.title}>
                <h3 className="font-serif italic text-[22px] text-accent">{pillar.title}</h3>
                <p className="font-sans text-[10px] tracking-[0.15em] text-text-secondary uppercase mt-1">
                  {pillar.subtitle}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const Carta = () => {
  const menuItems = [
    { name: "Carpaccio de Lacón \"Á Feira\"", price: "13€" },
    { name: "Ensalada de Burrata con Vinagreta de Miel y Mostaza", price: "14€" },
    { name: "Chocos Guisados en su Tinta con Patatas", price: "14€" },
    { name: "Langostinos Crujientes con Alioli Suave", price: "14€" },
    { name: "Croquetas de Jamón de Cebo Ibérico", price: "10€" },
    { name: "Cazuela de Pulpo con Queso Arzúa-Ulloa", price: "18€" },
    { name: "Bivalvo del Día", price: "S/M" },
    { name: "Arroz Cremoso de Secreto y Portobello", price: "20€" },
    { name: "Canelones de Queso Fresco y Espinacas", price: "14€" },
    { name: "Bacalao con Cremoso de Patata y Ajada", price: "17€" },
    { name: "Merluza con Zamburiñas en Salsa Verde", price: "18€" },
    { name: "Costilla de Cerdo a Baja Temperatura con Costra de Mayonesa de Chimichurri", price: "16€" },
    { name: "Croca de Ternera y Foie en Salsa de Oporto", price: "22€" },
    { name: "Postres Caseros", price: "5,5€" },
    { name: "Servicio Pan (pax)", price: "1€" }
  ];

  return (
    <section id="carta" className="py-[100px] bg-bg-carta scroll-mt-16">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center mb-16">
          <span className="font-sans text-[11px] tracking-[0.15em] text-accent uppercase block reveal">
            LA CARTA
          </span>
          <h2 className="text-[56px] md:text-[64px] text-text-primary reveal stagger-1">
            El Producto
          </h2>
        </div>

        <div className="flex flex-col md:flex-row gap-16 md:items-stretch">
          {/* Menu List */}
          <div className="w-full md:w-[55%] reveal">
            {menuItems.map((item, idx) => (
              <div 
                key={idx} 
                className="flex justify-between items-baseline py-4 border-b border-border group reveal"
                style={{ transitionDelay: `${idx * 0.05}s` }}
              >
                <span className="font-serif text-[18px] text-text-primary group-hover:text-accent transition-colors duration-200">
                  {item.name}
                </span>
                <span className="font-sans text-[13px] text-text-secondary ml-4">
                  {item.price}
                </span>
              </div>
            ))}
          </div>

          {/* Photos */}
          <div className="w-full md:w-[40%] flex flex-col gap-4 reveal stagger-2">
            {[prato1, prato2, prato3].map((img, idx) => (
              <div 
                key={idx} 
                className="flex-1 aspect-[4/3] md:aspect-auto bg-[#e5e0d8] w-full bg-cover bg-center"
                style={{ backgroundImage: `url("${img}")` }}
              ></div>
            ))}
          </div>
        </div>

        {/* Menú para Grupos */}
        <div className="mt-32 reveal">
          <div className="relative bg-white border border-border p-8 md:p-12 max-w-4xl mx-auto shadow-sm reveal stagger-1">
            {/* Decorative Label */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-bg-carta px-6">
              <span className="font-sans text-[10px] tracking-[0.2em] text-accent uppercase whitespace-nowrap">
                MENÚ PARA GRUPOS
              </span>
            </div>

            <div className="flex justify-between items-baseline border-b border-border pb-6 mb-8">
              <h3 className="text-[36px]">Menú cerrado</h3>
              <span className="font-serif text-[44px] text-accent">35€ <small className="text-sm text-text-secondary font-sans uppercase tracking-widest">por persona</small></span>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <span className="font-sans text-[10px] tracking-[0.15em] text-accent uppercase block mb-4">3 ENTRANTES A ELEGIR</span>
                <ul className="space-y-2">
                  {["Carpaccio de Lacón Á Feira", "Cazuela de Pulpo y Arzúa", "Ensalada de Burrata", "Tabla de Embutidos", "Zamburiñas a la Plancha con Aceite de Ajo y Perejil", "Croquetas de Jamón"].map(item => (
                    <li key={item} className="text-[14px] font-light text-text-primary py-1.5 border-b border-[#F0EBE3]">{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <span className="font-sans text-[10px] tracking-[0.15em] text-accent uppercase block mb-4">PLATO PRINCIPAL A ELEGIR</span>
                <ul className="space-y-2">
                  {["Merluza con Cremoso de Patata y Ajada", "Secreto de Cerdo con Mayonesa de Chimichurri", "Canelones de Queso Fresco y Espinacas"].map(item => (
                    <li key={item} className="text-[14px] font-light text-text-primary py-1.5 border-b border-[#F0EBE3]">{item}</li>
                  ))}
                </ul>
                <div className="mt-8">
                  <span className="font-sans text-[10px] tracking-[0.15em] text-accent uppercase block mb-2">INCLUIDO</span>
                  <p className="text-[14px] font-light">Postre casero, café y chupito</p>
                </div>
              </div>
            </div>

            <p className="mt-10 text-[12px] text-text-secondary italic border-t border-border pt-6">
              Cada menú incluye 3 consumiciones por persona (refresco o cerveza) o 1 botella de vino para cada 2.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const Atmosfera = () => {
  const photos = [
    { image: ats1, size: "medium" },
    { placeholder: "Quote card dark background: 'Cada detalle coidado, sen artificios.'", size: "small", type: "text" },
    { image: ats3, size: "medium" },
    { image: ats2, size: "medium" },
    { image: ats4, size: "medium" },
    { image: ats5, size: "medium" }
  ];

  return (
    <section id="espazo" className="py-[100px] bg-bg-dark scroll-mt-16">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <h2 className="text-[48px] md:text-[56px] italic text-text-cream text-center mb-16 font-light reveal">
          Atmósfera
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 reveal stagger-1 items-center">
          {photos.map((photo, idx) => (
            <div 
              key={idx} 
              className={`reveal stagger-${(idx % 4) + 1} ${
                photo.type === 'text' 
                  ? 'aspect-[2/1] md:aspect-square bg-bg-dark border border-white/10 flex items-center justify-center p-8' 
                  : 'aspect-[4/3] md:aspect-square bg-[#3a3530] bg-cover bg-center'
              }`}
              style={photo.image ? { backgroundImage: `url("${photo.image}")` } : {}}
            >
              {photo.type === 'text' && (
                <p className="font-serif italic text-[18px] md:text-[20px] text-text-cream/80 text-center">
                  "Cada detalle coidado, sen artificios."
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Reservas = () => {
  return (
    <section id="contacto" className="py-[120px] bg-bg-primary relative overflow-hidden scroll-mt-16">
      {/* Subtle background image detail */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none bg-cover bg-center grayscale"
        style={{ backgroundImage: `url("${headerImage}")` }}
      ></div>

      <div className="max-w-[750px] mx-auto px-6 reveal relative z-10">
        <div className="bg-white border border-border p-12 md:p-16 text-center shadow-sm">
          <div className="inline-block border border-accent px-4 py-1.5 mb-6">
            <span className="font-sans text-[10px] tracking-[0.15em] text-accent uppercase">EXPERIENCIA NORO</span>
          </div>
          <h2 className="text-[44px] md:text-[52px] text-text-primary leading-tight reveal stagger-1">
            A Túa Mesa Agarda
          </h2>
          <p className="text-text-secondary text-[14px] mt-5 leading-relaxed reveal stagger-2">
            O noso comedor é pequeno e íntimo. Recomendamos reservar con antelación para poder recibirte como mereces. Todas as reservas xestionámolas de forma persoal por WhatsApp para que cada visita sexa especial.
          </p>
          
          <a
            href="https://wa.me/34886642422"
            className="inline-block mt-8 bg-accent text-white px-12 py-4.5 text-[12px] tracking-[0.1em] hover:bg-accent-hover transition-colors reveal stagger-3"
          >
            RESERVAR POR WHATSAPP
          </a>

          <div className="h-px bg-border w-full my-8"></div>

          <div className="flex flex-col items-center text-center reveal stagger-4">
            <div>
              <h4 className="font-serif italic text-[18px] text-accent mb-3">Horario</h4>
              <div className="text-[13px] text-text-secondary space-y-1.5 leading-relaxed">
                <p>Mar - Sáb: 13:30 - 16:00</p>
                <p>20:30 - 23:30</p>
                <p>Dom: 13:00 - 16:00</p>
                <p>Luns: Pechado</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Ubicacion = () => {
  return (
    <section className="h-[600px] flex flex-col md:flex-row bg-bg-beige overflow-hidden">
      {/* Decorative Map Column */}
      <div className="w-full md:w-[60%] h-1/2 md:h-full relative bg-bg-beige flex items-center justify-center">
        {/* SVG Decorative Map */}
        <svg width="400" height="400" viewBox="0 0 400 400" className="opacity-25">
          <circle cx="200" cy="200" r="50" fill="none" stroke="#B05A3A" strokeWidth="1" />
          <circle cx="200" cy="200" r="100" fill="none" stroke="#B05A3A" strokeWidth="1" />
          <circle cx="200" cy="200" r="150" fill="none" stroke="#B05A3A" strokeWidth="1" />
          <circle cx="200" cy="200" r="200" fill="none" stroke="#B05A3A" strokeWidth="1" />
        </svg>
        <div className="absolute w-2 h-2 bg-accent rounded-full"></div>
        {/* Grid Overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.08]" 
             style={{ backgroundImage: 'linear-gradient(#B05A3A 1px, transparent 1px), linear-gradient(90deg, #B05A3A 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
        </div>
      </div>

      {/* Info Column */}
      <div className="w-full md:w-[40%] h-1/2 md:h-full bg-white p-12 md:p-16 flex flex-col justify-center reveal">
        <span className="font-sans text-[11px] tracking-[0.15em] text-accent uppercase block reveal">
          UBICACIÓN
        </span>
        <h2 className="text-[36px] md:text-[44px] text-text-primary mt-4 leading-tight reveal stagger-1">
          No corazón de Pontevedra
        </h2>
        <div className="mt-6 text-[14px] text-text-secondary space-y-1 leading-relaxed reveal stagger-2">
          <p>Rúa Padre Luis María Fernández, 3</p>
          <p>36002 Pontevedra</p>
          <p>Galicia, España</p>
        </div>
        <p className="mt-4 text-[13px] text-text-secondary italic reveal stagger-3">
          No centro histórico de Pontevedra, a poucos pasos do Santuario da Peregrina.
        </p>
        <a
          href="https://maps.google.com/?q=Rúa+Padre+Luis+María+Fernández+3+Pontevedra"
          className="inline-block mt-8 border border-text-primary text-text-primary px-8 py-3.5 text-[11px] tracking-[0.1em] hover:bg-text-primary hover:text-white transition-all self-start reveal stagger-4"
        >
          VER EN GOOGLE MAPS
        </a>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-bg-dark pt-20 pb-10 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 md:gap-12">
          {/* Col 1 */}
          <div>
            <img src={logoImage} alt="noro" className="h-10 w-auto brightness-0 invert" />
            <p className="font-sans text-[13px] text-[#9C9A8E] mt-6 leading-relaxed max-w-[280px]">
              Cociña xeitosa. Cociña galega contemporánea no corazón de Pontevedra. Un lugar onde o tempo pasa amodo e as sobremesas se estiran.
            </p>
            <div className="flex gap-4 mt-6">
              {["INSTAGRAM", "FACEBOOK"].map(social => (
                <a key={social} href="#" className="text-[11px] tracking-[0.1em] text-[#9C9A8E] hover:text-text-cream transition-colors">
                  {social}
                </a>
              ))}
            </div>
          </div>

          {/* Col 2 */}
          <div>
            <span className="font-sans text-[11px] tracking-[0.15em] text-accent uppercase block mb-6">HORARIO</span>
            <div className="space-y-4">
              <div>
                <span className="text-[10px] tracking-[0.1em] text-[#9C9A8E] uppercase block mb-1">MARTES - SÁBADO</span>
                <p className="text-[13px] text-text-cream leading-relaxed">13:30 - 16:00<br/>20:30 - 23:30</p>
              </div>
              <div>
                <span className="text-[10px] tracking-[0.1em] text-[#9C9A8E] uppercase block mb-1">DOMINGO</span>
                <p className="text-[13px] text-text-cream">13:00 - 16:00</p>
              </div>
              <div>
                <span className="text-[10px] tracking-[0.1em] text-[#9C9A8E] uppercase block mb-1">LUNS</span>
                <p className="text-[13px] text-text-cream">Pechado</p>
              </div>
            </div>
          </div>

          {/* Col 3 */}
          <div>
            <span className="font-sans text-[11px] tracking-[0.15em] text-accent uppercase block mb-6">CONTACTO</span>
            <div className="text-[13px] text-text-cream space-y-1 leading-relaxed">
              <p>Rúa Padre Luis María Fernández, 3</p>
              <p>36002 Pontevedra</p>
              <p>Galicia, España</p>
            </div>
            <a href="tel:886642422" className="block mt-4 text-[13px] text-accent">886 64 24 22</a>
            <a href="mailto:reservas@nororestaurante.es" className="block text-[13px] text-accent">reservas@nororestaurante.es</a>
          </div>
        </div>

        <div className="h-px bg-white/10 w-full mt-16 mb-8"></div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] text-[#9C9A8E] tracking-wider">
          <span>© 2026 NORO COCIÑA XEITOSA</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-text-cream transition-colors">AVISO LEGAL</a>
            <a href="#" className="hover:text-text-cream transition-colors">PRIVACIDADE</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

const WhatsAppButton = () => {
  return (
    <a 
      href="https://wa.me/34886642422"
      className="fixed bottom-6 right-6 w-14 h-14 bg-accent rounded-full flex items-center justify-center shadow-lg z-[999] hover:scale-105 hover:bg-accent-hover transition-all"
    >
      <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    </a>
  );
};

// --- Main App ---

export default function App() {
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, observerOptions);

    const revealElements = document.querySelectorAll('.reveal');
    revealElements.forEach(el => observer.observe(el));

    return () => {
      revealElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Filosofia />
      <Carta />
      <Atmosfera />
      <Reservas />
      <Ubicacion />
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
